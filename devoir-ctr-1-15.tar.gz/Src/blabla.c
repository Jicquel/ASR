#include <stdio.h>

int main(int argc, char *argv[]) {

  while (1) {
     printf("Bla-bla-bla?\n"); 
     printf("Bla-bla-bla!\n");
     printf("Bla-bla-bla...\n");
     sleep(2);
  }
}

